# MPL

1. Counting number of positive and negative numbers in an array
2. Block transfer using overlapping and non overlapping
3. BCD TO HEX Convertor
4. Multiplication of numbers(Add and shift, Successove add method)
5. Program to find occurences of space,enter,character in file using global,extern
6. Display LDTR,GDTR,IDTR,TR values
7. Bubble sort
8. DOS Commands TYPE,COPY,DELETE
9. Factorial of number
10. Mean,variance,standard deviation
11. Roots of Quadratic equation
